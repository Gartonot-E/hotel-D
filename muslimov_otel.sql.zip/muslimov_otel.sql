-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июл 04 2021 г., 10:01
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `muslimov_otel`
--

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--
-- Создание: Апр 14 2021 г., 11:06
-- Последнее обновление: Июн 23 2021 г., 11:01
--

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `text` varchar(255) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `name`, `text`, `date`) VALUES
(59, 'Компания Капитал-Консалтинг', 'Оставались в Махачкале, жили в Президенте, очень довольны сервисом и всем остальным! Администрации отеля большой привет от Андрея Лобанова и Александра!', '28/03/2011'),
(60, 'Марат', 'Как то раз приехал в махачкалу и думал где остановится, выбор пал на президент отель сервис шикарный.', '03/05/2011');

-- --------------------------------------------------------

--
-- Структура таблицы `rooms`
--
-- Создание: Апр 14 2021 г., 11:06
-- Последнее обновление: Июн 27 2021 г., 13:06
--

DROP TABLE IF EXISTS `rooms`;
CREATE TABLE `rooms` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `rooms` varchar(255) NOT NULL,
  `datazaezda` varchar(255) NOT NULL,
  `timezaezda` varchar(255) NOT NULL,
  `dataviezda` varchar(255) NOT NULL,
  `timeviezda` varchar(255) NOT NULL,
  `dop` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `rooms`
--

INSERT INTO `rooms` (`id`, `name`, `phone`, `rooms`, `datazaezda`, `timezaezda`, `dataviezda`, `timeviezda`, `dop`) VALUES
(9, 'Иванов Иван', '+7 (999) 123-4567', 'Стандарт улучшенный 2-х комнатный', '2021-04-14', '05:24', '2021-04-25', '00:00', 'Хотелось бы узнать расписание завтраков'),
(10, 'Вагид', '+7 (988) 290-2327', 'Стандарт 2-х местный', '2021-04-14', '14:10', '2021-04-14', '15:15', '123'),
(11, 'Гамид Алибеков', '+7 (988) 290-2327', 'Стандарт улучшенный 2-х комнатный', '2021-04-16', '22:27', '2021-04-17', '23:03', 'Хочу ковер'),
(12, 'Вагид', '+7 (988) 290-2327', 'Стандарт 2-х комнатный', '2021-04-23', '22:20', '2021-04-17', '02:20', ''),
(13, 'Альбина ', '+7 (988) 634-3973', 'Стандарт улучшенный', '2021-04-28', '22:40', '2021-04-30', '22:44', 'Чистая'),
(14, 'Вагид Муслимов', '+7 (988) 292-9399', 'Стандарт', '2021-06-22', '21:04', '2021-06-22', '21:04', ''),
(15, 'contteeax', '1234567890', '', '2021-06-23', '12:27', '', '', 'Доброго времени суток! \r\n \r\nРазошлём ваши предложения через формы обратной связи сайтов фирм Российской Федерации и СНГ.  \r\nПредлагаем рассылку через контактные-формы сайтов организаций по любым странам и доменным зонам мира на любых языках.  \r\n \r\nhttps:/'),
(16, 'fafa', '+7 (982) 828-2828', 'Стандарт с раскидным диваном', '2021-06-23', '13:59', '2021-07-02', '18:00', 'dasdas'),
(17, 'Тамара', '79855718522', 'Стандарт', '2021-06-27', '16:06', '8238208', '8238208', 'Добрый день, Направим новых клиентов на Ваш сайт (www.hotel-dag.ru). подробнее смотрите по ссылке  https://bit.ly/3bWmvS8?id=www.hotel-dag.ru');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT для таблицы `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
